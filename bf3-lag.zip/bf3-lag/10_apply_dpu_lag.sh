#!/usr/bin/env bash
# Run on DPU ARM over independent TMFIFO, from HGX KVM terminal.
set -Eeuo pipefail
BASE=/var/lib/bf3-lag
TARGET_MTU=${1:-1500}
[[ "$TARGET_MTU" =~ ^[0-9]+$ ]] && (( TARGET_MTU >= 1500 && TARGET_MTU <= 9000 )) || { echo "Invalid MTU $TARGET_MTU"; exit 1; }
SELF="$(cd -- "$(dirname -- "$0")" && pwd)"
[[ $(id -u) -eq 0 ]] || { echo 'sudo bash required'; exit 1; }
for c in ovs-vsctl ovs-ofctl ip grep modprobe; do command -v "$c" >/dev/null || exit 1; done
[[ -f /etc/mellanox/mlnx-bf.conf ]] || { echo 'Missing mlnx-bf.conf'; exit 1; }
grep -Eq '^LAG_HASH_MODE=["\x27]?yes["\x27]?' /etc/mellanox/mlnx-bf.conf || {
  echo 'LAG_HASH_MODE=yes not present. Firmware+config prerequisite missing'; exit 1;
}
for d in p0 p1 pf0hpf pf1hpf; do ip link show "$d" >/dev/null || { echo "No $d"; exit 1; }; done
for p in 'p0 ovsbr1' 'p1 ovsbr2' 'pf0hpf ovsbr1' 'pf1hpf ovsbr2'; do
  set -- $p
  got=$(ovs-vsctl port-to-br "$1" 2>/dev/null || true)
  [[ "$got" == "$2" ]] || { echo "Wrong initial OVS placement: $1 -> $got (expected $2)"; exit 1; }
done
! ip link show bond0 >/dev/null 2>&1 || { echo 'DPU bond0 already exists. No destructive overwrite'; exit 1; }
mkdir -p "$BASE"
if [[ -e "$BASE/applied" ]]; then echo 'Already marked applied'; exit 1; fi
ovs-vsctl show > "$BASE/ovs-before.txt"
ovs-ofctl -O OpenFlow13 dump-flows ovsbr1 > "$BASE/ovsbr1-before.flows.txt"
ovs-ofctl -O OpenFlow13 dump-flows ovsbr2 > "$BASE/ovsbr2-before.flows.txt"
ip -d link show p0 > "$BASE/p0-before.txt"
ip -d link show p1 > "$BASE/p1-before.txt"
for d in p0 p1 pf0hpf pf1hpf; do cat "/sys/class/net/$d/mtu" > "$BASE/mtu-$d"; done
# Refuse custom policies: we only know how to restore default NORMAL safely.
for br in ovsbr1 ovsbr2; do
  flows=$(ovs-ofctl -O OpenFlow13 dump-flows "$br" | grep -E 'actions=' || true)
  [[ $(printf '%s\n' "$flows" | grep -c 'actions=' || true) == 1 ]] || { echo "$br has non-default flows; aborting"; exit 1; }
  grep -q 'priority=0 actions=NORMAL' <<< "$flows" || { echo "$br not plain NORMAL; aborting"; exit 1; }
done
for br in ovsbr1 ovsbr2; do
  meters=$(ovs-ofctl -O OpenFlow13 dump-meters "$br")
  if grep -q 'meter=' <<< "$meters"; then echo "Meters on $br; aborting"; exit 1; fi
done
modprobe bonding
ip link add bond0 type bond
trap 'echo "DPU apply failed; running local rollback"; bash "$SELF/11_rollback_dpu.sh" || true' ERR
ip link set bond0 down
ip link set bond0 type bond mode 802.3ad miimon 100 xmit_hash_policy layer3+4 lacp_rate fast
# Downtime begins at the following OVS operation.
ovs-vsctl --if-exists del-port ovsbr1 p0
ovs-vsctl --if-exists del-port ovsbr2 p1
ovs-vsctl --if-exists del-port ovsbr2 pf1hpf
ip link set p0 down
ip link set p1 down
ip link set p0 master bond0
ip link set p1 master bond0
ip link set bond0 mtu "$TARGET_MTU"
ip link set pf0hpf mtu "$TARGET_MTU"
ip link set p0 up
ip link set p1 up
ip link set bond0 up
# Keep OVS bridge, pf0hpf, and SF0. DPU bond is sole uplink.
ovs-vsctl --may-exist add-port ovsbr1 bond0
[[ $(ovs-vsctl port-to-br pf0hpf) == ovsbr1 ]]
[[ $(ovs-vsctl port-to-br bond0) == ovsbr1 ]]
[[ $(ovs-vsctl port-to-br p0 2>/dev/null || true) == '' ]]
[[ $(ovs-vsctl port-to-br p1 2>/dev/null || true) == '' ]]
touch "$BASE/applied"
trap - ERR
echo 'DPU runtime LAG topology configured. Public networking may still be down!'
echo 'Proceed promptly with 20_apply_host.sh ON THE HOST KVM; then verify LACP.'
cat /proc/net/bonding/bond0
ovs-vsctl show
