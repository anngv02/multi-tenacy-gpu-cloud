#!/usr/bin/env bash
# Run on HGX KVM console with RShim TMFIFO to restore both halves.
set -u
SELF="$(cd -- "$(dirname -- "$0")" && pwd)"
[[ $(id -u) -eq 0 ]] || { echo 'Run as root'; exit 1; }
echo '[1/2] DPU runtime OVS+port rollback (independent TMFIFO)'
if ssh -tt -o ConnectTimeout=8 ubuntu@192.168.100.2 \
  'sudo bash ~/bf3-lag/11_rollback_dpu.sh'; then
  echo 'DPU runtime rollback returned success.'
else
  echo 'DPU rollback did not complete. Do not assume Ethernet has recovered.'
  echo 'Fix RShim/TMFIFO or use /dev/rshim0/console, run 11_rollback_dpu.sh directly on ARM.'
  exit 1
fi
echo '[2/2] Restoring original Host Netplan'
if bash "$SELF/21_rollback_host.sh"; then
  echo 'ROLLBACK COMPLETED: check public + private reachability and Host bond.'
else
  echo 'Host rollback failed; fix from KVM, original backup /root/bf3-lag/state/orig-netplan'
  exit 1
fi
