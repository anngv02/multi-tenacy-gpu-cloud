#!/usr/bin/env bash
# KVM-controlled cutover with best-effort automatic two-sided rollback.
# MUST run interactively on HGX Host KVM console, not an Ethernet SSH session.
set -Eeuo pipefail
SELF="$(cd -- "$(dirname -- "$0")" && pwd)"
[[ $(id -u) -eq 0 ]] || { echo 'sudo/root required'; exit 1; }
[[ "${ACK_TOR_LACP:-}" == YES ]] || {
  echo 'STOP: confirm p0+p1 belong to a single LACP System/Key and VLAN 1302/3048 are allowed';
  echo 'Then run: ACK_TOR_LACP=YES bash 40_cutover_from_kvm.sh'; exit 1;
}
[[ -f /root/bf3-lag/state/host-prepared ]] || { echo 'Run 00_prepare_host.sh'; exit 1; }
[[ -e /dev/rshim0/misc ]] || { echo '/dev/rshim0/misc missing: restore RShim'; exit 1; }
ip -4 route get 192.168.100.2 | grep -q 'dev tmfifo_net0' || { echo 'TMFIFO route incorrect'; exit 1; }
[[ -f "$SELF/90_rollback_from_kvm.sh" ]] || { echo 'Missing rollback controller'; exit 1; }
# Fail before change if remote rollback is missing or sudo requires unsupported interaction.
ssh -tt -o ConnectTimeout=8 ubuntu@192.168.100.2   'sudo test -f ~/bf3-lag/11_rollback_dpu.sh && echo DPU_ROLLBACK_READY' || {
  echo 'DPU rollback is not accessible; do not cut over'; exit 1;
}
# Use a marker set immediately before the first potentially disruptive operation.
# EXIT handler attempts DPU-first rollback, then Host restore, and can prompt
# for ubuntu password in the interactive KVM terminal. Do not leave KVM unattended.
MAY_HAVE_CHANGED=0
COMMITTED=0
on_exit() {
  local rc=$?
  trap - EXIT INT TERM
  if (( MAY_HAVE_CHANGED == 1 && COMMITTED == 0 )); then
    echo "[CUTOVER FAILED rc=$rc] Attempting two-sided rollback from KVM ..."
    if ! bash "$SELF/90_rollback_from_kvm.sh"; then
      echo 'CRITICAL: automatic rollback incomplete; manually run 90_rollback_from_kvm.sh via KVM'
      echo 'If TMFIFO unavailable, use ARM console for 11_rollback_dpu.sh, then 21_rollback_host.sh'
    fi
  fi
  exit "$rc"
}
trap on_exit EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
HOST_MTU=$(cat /sys/class/net/bond0/mtu)
echo "[1/3] Configure DPU bond using Host MTU $HOST_MTU; Ethernet interruption begins"
MAY_HAVE_CHANGED=1
ssh -tt -o ConnectTimeout=8 -o ServerAliveInterval=10 -o ServerAliveCountMax=3   ubuntu@192.168.100.2 "sudo bash ~/bf3-lag/10_apply_dpu_lag.sh $HOST_MTU"
echo '[2/3] Verify two-member DPU LACP BEFORE touching Host Netplan (up to 120 s)'
ssh -tt -o ConnectTimeout=8 -o ServerAliveInterval=10 -o ServerAliveCountMax=3   ubuntu@192.168.100.2 'sudo bash ~/bf3-lag/31_verify_dpu.sh'
echo '[3/3] LACP accepted; applying Host VLAN parent PF0 and checking public route'
bash "$SELF/20_apply_host.sh"
COMMITTED=1
trap - EXIT INT TERM
echo 'SUCCESS: two-member DPU LAG, Host VLAN parents/IPs and public peer validated. Private L3 still requires a known peer.'
echo 'NEXT: bash bf3-lag.sh verify-runtime, then bash bf3-lag.sh install-persistence'
