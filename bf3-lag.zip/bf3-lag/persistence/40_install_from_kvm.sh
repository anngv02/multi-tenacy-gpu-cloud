#!/usr/bin/env bash
# Run from HGX KVM as root in a writable directory containing this bundle.
set -Eeuo pipefail
[[ $(id -u) -eq 0 ]] || { echo 'Run as root on Host KVM'; exit 1; }
SELF=$(cd -- "$(dirname -- "$0")" && pwd)
[[ -e /dev/rshim0/misc ]] || { echo 'RShim not attached'; exit 1; }
ip -4 route get 192.168.100.2 | grep -q 'dev tmfifo_net0' || { echo 'Bad TMFIFO route'; exit 1; }
# Validate target Host state BEFORE touching anything.
[[ -e /sys/class/net/bond0.1302/lower_enp39s0f0np0 ]] || { echo 'Host public VLAN parent not PF0'; exit 1; }
bash "$SELF/30_install_host_mgmt.sh" --check
# Dry-stage package to DPU; scp / ssh will prompt interactively on KVM.
trap 'echo "Persistence did not finish. Do not reboot. Inspect DPU/Host backups and README recovery." >&2' ERR
echo '[1/3] Copying persistence files to BlueField ARM through TMFIFO'
ssh -tt ubuntu@192.168.100.2 'mkdir -p ~/bf3-lag/persistence'
scp "$SELF"/{10_dpu_preflight.sh,20_install_dpu.sh,21_remove_dpu_persistence.sh,51_verify_dpu_persistence.sh,70-bf3-lag.yaml,98-bf3-lag-unmanaged.conf,bf3-lag-reconcile,bf3-lag-reconcile.service} ubuntu@192.168.100.2:~/bf3-lag/persistence/
echo '[2/3] Preflight+install DPU boot persistence: NO live networking changes'
ssh -tt ubuntu@192.168.100.2 'sudo bash ~/bf3-lag/persistence/20_install_dpu.sh'
echo '[3/3] Install Host management persistence for RShim/TMFIFO'
bash "$SELF/30_install_host_mgmt.sh"
bash "$SELF/50_verify_from_kvm.sh" staged
echo 'SUCCESS: Persistence STAGED on DPU+Host. Reboot acceptance still required.'
