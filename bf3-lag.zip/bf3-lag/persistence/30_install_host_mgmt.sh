#!/usr/bin/env bash
# Run on HGX Host KVM. Only makes Host RShim and TMFIFO persistent.
set -Eeuo pipefail
[[ $(id -u) -eq 0 ]] || exit 1
SELF=$(cd -- "$(dirname -- "$0")" && pwd)
BASE=/root/bf3-lag-persistence-backup
CFG=/etc/netplan/90-bf3-tmfifo-host.yaml
[[ ! -e "$BASE/netplan-before" ]] || { echo "Existing Host backup: $BASE; inspect previous installation"; exit 1; }
[[ ! -e "$CFG" ]] || { echo "$CFG already exists. Stop to avoid overwrite."; exit 1; }
[[ -e /dev/rshim0/misc ]] || { echo 'Host RShim not attached'; exit 1; }
ip -4 route get 192.168.100.2 | grep -q 'dev tmfifo_net0' || { echo 'TMFIFO route missing'; exit 1; }
[[ -e /sys/class/net/bond0.1302/lower_enp39s0f0np0 ]] || { echo 'Host public VLAN no longer on PF0'; exit 1; }
if grep -REl '^\s*tmfifo_net0:' /etc/netplan/ 2>/dev/null; then
  echo 'TMFIFO is defined in an existing Host Netplan. Stop, do not create a second definition.'; exit 1
fi
ROOT=$(mktemp -d)
trap 'rm -rf "$ROOT"' EXIT
mkdir -p "$ROOT/etc/netplan"
cp -a /etc/netplan/. "$ROOT/etc/netplan/"
cp "$SELF/90-bf3-tmfifo-host.yaml" "$ROOT/etc/netplan/90-bf3-tmfifo-host.yaml"
netplan generate --root-dir "$ROOT"
if [[ ${1:-install} == --check ]]; then
  echo 'Host management persistence preflight passed (offline, no installation).'
  exit 0
fi
mkdir -p "$BASE"
[[ ! -e "$BASE/installed" ]] || { echo 'Already installed'; exit 1; }
cp -a /etc/netplan "$BASE/netplan-before"
if systemctl is-enabled --quiet rshim; then echo enabled > "$BASE/rshim-original"; else echo disabled > "$BASE/rshim-original"; fi
install -m 600 "$SELF/90-bf3-tmfifo-host.yaml" "$CFG"
systemctl enable rshim
cat /proc/sys/kernel/random/boot_id > "$BASE/install-boot-id"
printf 'installed\n' > "$BASE/installed"
echo 'Host persistent RShim+TMFIFO staged. Current Host PF0/VLAN networking untouched.'
echo 'No netplan apply, no rshim restart.'
