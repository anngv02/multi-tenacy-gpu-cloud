#!/usr/bin/env bash
# Removes boot persistence only. DOES NOT convert live DPU bond back to two bridges.
set -Eeuo pipefail
[[ $(id -u) -eq 0 ]] || exit 1
systemctl disable --now bf3-lag-reconcile.service || { echo "Cannot stop reconcile; abort removal"; exit 1; }
rm -f /etc/systemd/system/bf3-lag-reconcile.service
rm -f /usr/local/sbin/bf3-lag-reconcile
rm -f /etc/netplan/70-bf3-lag.yaml
rm -f /etc/NetworkManager/conf.d/98-bf3-lag-unmanaged.conf
systemctl daemon-reload
rm -f /var/lib/bf3-lag-persistence/installed
echo 'Generated /run/systemd/network files may still own bond0; read README before runtime rollback.'
echo 'Removed startup persistence only. Current DPU LAG is UNCHANGED.'
echo 'Do NOT reboot in this state expecting Host networking to work.'
