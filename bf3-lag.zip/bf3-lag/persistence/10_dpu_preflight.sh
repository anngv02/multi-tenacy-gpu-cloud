#!/usr/bin/env bash
# Read-only preflight on BlueField-3 ARM OS.
set -Eeuo pipefail
[[ $(id -u) -eq 0 ]] || { echo 'Run: sudo bash 10_dpu_preflight.sh'; exit 1; }
for cmd in ip ovs-vsctl netplan systemctl awk grep; do command -v "$cmd" >/dev/null || { echo "Missing $cmd"; exit 1; }; done
[[ -f /etc/mellanox/mlnx-bf.conf ]] || { echo 'Missing /etc/mellanox/mlnx-bf.conf'; exit 1; }
grep -Eq '^LAG_HASH_MODE="?yes"?' /etc/mellanox/mlnx-bf.conf || { echo 'LAG_HASH_MODE=yes missing'; exit 1; }
for dev in p0 p1 pf0hpf; do ip link show dev "$dev" >/dev/null; done
[[ -f /proc/net/bonding/bond0 ]] || { echo 'Missing DPU bond0'; exit 1; }
[[ "$(cat /sys/class/net/bond0/bonding/ad_num_ports)" == 2 ]] || { echo 'bond0 does not have 2 active LACP links'; exit 1; }
[[ "$(cat /sys/class/net/bond0/bonding/slaves)" == 'p0 p1' || "$(cat /sys/class/net/bond0/bonding/slaves)" == 'p1 p0' ]] || { echo 'Unexpected bond0 slaves'; exit 1; }
for spec in 'bond0 ovsbr1' 'pf0hpf ovsbr1'; do
  read -r dev bridge <<<"$spec"
  [[ "$(ovs-vsctl port-to-br "$dev")" == "$bridge" ]] || { echo "$dev is not in $bridge"; exit 1; }
done
TARGET_MTU=$(cat /sys/class/net/bond0/mtu)
[[ "$TARGET_MTU" =~ ^[0-9]+$ ]] && (( TARGET_MTU >= 1500 && TARGET_MTU <= 9000 )) || { echo 'Invalid runtime MTU'; exit 1; }
[[ "$(cat /sys/class/net/pf0hpf/mtu)" == "$TARGET_MTU" ]] || { echo 'pf0hpf/bond0 MTU mismatch'; exit 1; }
[[ -z "$(ovs-vsctl port-to-br pf1hpf 2>/dev/null || true)" ]] || { echo 'pf1hpf must be removed from OVS'; exit 1; }
for dev in p0 p1; do
  [[ -z "$(ovs-vsctl port-to-br "$dev" 2>/dev/null || true)" ]] || { echo "$dev must not be an OVS port"; exit 1; }
  [[ "$(cat /sys/class/net/$dev/mtu)" == "$TARGET_MTU" ]] || { echo "$dev MTU differs from bond0"; exit 1; }
  ip -d link show dev "$dev" | grep -q 'ad_actor_oper_port_state_str <.*collecting,distributing>' || { echo "$dev actor not collecting/distributing"; exit 1; }
  ip -d link show dev "$dev" | grep -q 'ad_partner_oper_port_state_str <.*collecting,distributing>' || { echo "$dev partner not collecting/distributing"; exit 1; }
done
[[ "$(cat /sys/class/net/bond0/mtu)" == "$TARGET_MTU" ]] || { echo 'bond0 MTU mismatch'; exit 1; }
[[ "$(cat /sys/class/net/bond0/bonding/mode)" == '802.3ad 4' ]] || { echo 'bond0 mode mismatch'; exit 1; }
[[ "$(cat /sys/class/net/bond0/bonding/xmit_hash_policy)" == 'layer3+4 1' ]] || { echo 'bond0 hash policy mismatch'; exit 1; }
[[ "$(cat /sys/class/net/bond0/bonding/lacp_rate)" == 'fast 1' ]] || { echo 'bond0 LACP rate mismatch'; exit 1; }
echo '[OK] DPU two-member LACP, OVS port assignment, Hash Mode and MTU verified.'
echo 'NOTE: This check does not prove 400Gb/s application throughput.'
