#!/usr/bin/env bash
set -Eeuo pipefail
[[ $(id -u) -eq 0 ]] || exit 1
BASE=/root/bf3-lag-persistence-backup
rm -f /etc/netplan/90-bf3-tmfifo-host.yaml
if [[ "$(cat "$BASE/rshim-original" 2>/dev/null || echo enabled)" == disabled ]]; then
  systemctl disable rshim
fi
rm -f "$BASE/installed"
echo 'Removed Host boot persistence file. Runtime networking untouched.'
