#!/usr/bin/env bash
# Host KVM validation: staged and boot are separate acceptance gates.
set -Eeuo pipefail
[[ $(id -u) -eq 0 ]] || exit 1
SELF=$(cd -- "$(dirname -- "$0")" && pwd)
MODE=${1:-staged}
[[ "$MODE" == staged || "$MODE" == boot ]] || { echo 'Use staged or boot'; exit 2; }
bash "$SELF/../50_verify_runtime_from_kvm.sh"
echo '===== HGX PF0 VLANs ====='
for v in bond0.1302 bond0.3048; do
  ip -br addr show "$v"
  [[ -e /sys/class/net/$v/lower_enp39s0f0np0 ]] || exit 1
done
ip -4 route get 171.232.252.212 from 171.232.252.202
echo '===== HOST RSHIM + TMFIFO ====='
systemctl is-enabled rshim
systemctl is-active rshim
ip -4 route get 192.168.100.2 | grep 'dev tmfifo_net0'
[[ -s /etc/netplan/90-bf3-tmfifo-host.yaml ]]
[[ -e /dev/rshim0/misc ]]
[[ -f /root/bf3-lag-persistence-backup/installed ]]
cmp -s "$SELF/90-bf3-tmfifo-host.yaml" /etc/netplan/90-bf3-tmfifo-host.yaml || { echo 'Host TMFIFO config differs from bundle'; exit 1; }
if [[ "$MODE" == boot ]]; then
  [[ -s /root/bf3-lag-persistence-backup/install-boot-id ]]
  [[ $(cat /proc/sys/kernel/random/boot_id) != "$(cat /root/bf3-lag-persistence-backup/install-boot-id)" ]] || {
    echo 'Host has not rebooted since persistence installation'; exit 1;
  }
fi
echo '===== BLUEFIELD BOOT PERSISTENCE ====='
ssh -tt -o ConnectTimeout=8 ubuntu@192.168.100.2 "sudo bash ~/bf3-lag/persistence/51_verify_dpu_persistence.sh $MODE"
echo "PASS: persistence $MODE checks. Review private L3 and offloaded traffic separately."
