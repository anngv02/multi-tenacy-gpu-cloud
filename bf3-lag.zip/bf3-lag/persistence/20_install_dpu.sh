#!/usr/bin/env bash
# Install persistence on DPU ARM without changing the currently working datapath.
set -Eeuo pipefail
[[ $(id -u) -eq 0 ]] || { echo 'sudo bash 20_install_dpu.sh'; exit 1; }
SELF=$(cd -- "$(dirname -- "$0")" && pwd)
bash "$SELF/10_dpu_preflight.sh"
for cmd in netplan systemctl install mktemp cp python3; do command -v "$cmd" >/dev/null || exit 1; done
python3 -c 'import yaml'
TARGET_MTU=$(cat /sys/class/net/bond0/mtu)
BASE=/var/lib/bf3-lag-persistence
if [[ -e "$BASE/backup" ]]; then echo 'Already installed; refusing to overwrite saved baseline'; exit 1; fi
for file in /etc/netplan/70-bf3-lag.yaml /etc/NetworkManager/conf.d/98-bf3-lag-unmanaged.conf /etc/systemd/system/bf3-lag-reconcile.service /usr/local/sbin/bf3-lag-reconcile; do
  [[ ! -e "$file" ]] || { echo "Collision: $file exists, no overwrite"; exit 1; }
done
# Dry-run full merged netplan, including cloud-init and NVIDIA defaults.
ROOT=$(mktemp -d)
trap 'rm -rf "$ROOT"' EXIT
mkdir -p "$ROOT/etc/netplan"
cp -a /etc/netplan/. "$ROOT/etc/netplan/"
sed "s/mtu: 9000/mtu: $TARGET_MTU/g" "$SELF/70-bf3-lag.yaml" > "$ROOT/etc/netplan/70-bf3-lag.yaml"
chmod 600 "$ROOT/etc/netplan/70-bf3-lag.yaml"
netplan generate --root-dir "$ROOT"
for unit in "$ROOT"/run/systemd/network/*; do :; done
[[ -d "$ROOT/run/systemd/network" ]] || { echo 'No systemd-networkd output generated'; exit 1; }
echo '[OK] Offline netplan generate passed. No netplan apply/restart performed.'
mkdir -p "$BASE/backup" /etc/NetworkManager/conf.d /usr/local/sbin /etc/systemd/system
cp -a /etc/netplan "$BASE/backup/netplan-before"
ovs-vsctl show > "$BASE/backup/ovs-before.txt"
cat /proc/net/bonding/bond0 > "$BASE/backup/bond-before.txt"
nmcli device status > "$BASE/backup/nm-before.txt" 2>/dev/null || true
install -m 600 "$ROOT/etc/netplan/70-bf3-lag.yaml" /etc/netplan/70-bf3-lag.yaml
install -m 644 "$SELF/98-bf3-lag-unmanaged.conf" /etc/NetworkManager/conf.d/98-bf3-lag-unmanaged.conf
install -m 755 "$SELF/bf3-lag-reconcile" /usr/local/sbin/bf3-lag-reconcile
install -m 644 "$SELF/bf3-lag-reconcile.service" /etc/systemd/system/bf3-lag-reconcile.service
systemctl daemon-reload
systemctl enable bf3-lag-reconcile.service
printf '%s\n' 'Persistence installed; validated offline; current network intentionally untouched.'
cat /proc/sys/kernel/random/boot_id > "$BASE/install-boot-id"
touch "$BASE/installed"
bash "$SELF/10_dpu_preflight.sh"
echo '[NEXT] Check read-only status now. Reboot ONLY from Host KVM when ready.'
echo '       The service is enabled for next boot, NOT started now.'
