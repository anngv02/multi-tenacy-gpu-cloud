#!/usr/bin/env bash
set -Eeuo pipefail
SELF=$(cd -- "$(dirname -- "$0")" && pwd)
MODE=${1:-staged}
[[ "$MODE" == staged || "$MODE" == boot ]] || exit 2
bash "$SELF/10_dpu_preflight.sh"
[[ -f /var/lib/bf3-lag-persistence/installed ]]
for pair in \
  '98-bf3-lag-unmanaged.conf /etc/NetworkManager/conf.d/98-bf3-lag-unmanaged.conf' \
  'bf3-lag-reconcile /usr/local/sbin/bf3-lag-reconcile' \
  'bf3-lag-reconcile.service /etc/systemd/system/bf3-lag-reconcile.service'; do
  read -r source target <<< "$pair"
  cmp -s "$SELF/$source" "$target" || { echo "Installed file mismatch: $target"; exit 1; }
done
python3 - <<'PY'
from pathlib import Path
import yaml
n = yaml.safe_load(Path('/etc/netplan/70-bf3-lag.yaml').read_text())['network']
b = n['bonds']['bond0']
assert b['renderer'] == 'networkd' and set(b['interfaces']) == {'p0', 'p1'}
assert b['parameters'] == {'mode': '802.3ad', 'mii-monitor-interval': 100,
                           'lacp-rate': 'fast', 'transmit-hash-policy': 'layer3+4'}
for dev in ('bond0', 'p0', 'p1'):
    spec = b if dev == 'bond0' else n['ethernets'][dev]
    assert spec['renderer'] == 'networkd'
    assert spec['mtu'] == int(Path(f'/sys/class/net/{dev}/mtu').read_text()), dev
print('Persistent Netplan matches runtime MTU and LACP settings')
PY
systemctl is-enabled --quiet bf3-lag-reconcile.service
if [[ "$MODE" == boot ]]; then
  [[ -s /var/lib/bf3-lag-persistence/install-boot-id ]]
  [[ $(cat /proc/sys/kernel/random/boot_id) != "$(cat /var/lib/bf3-lag-persistence/install-boot-id)" ]] || {
    echo 'DPU has not rebooted since installation (Host reboot alone may not reboot ARM)'; exit 1;
  }
  systemctl is-active --quiet bf3-lag-reconcile.service
  [[ $(systemctl show bf3-lag-reconcile.service -p Result --value) == success ]]
  [[ $(systemctl show bf3-lag-reconcile.service -p ExecMainStatus --value) == 0 ]]
  [[ $(systemctl show bf3-lag-reconcile.service -p ExecMainStartTimestampMonotonic --value) != 0 ]]
else
  echo 'STAGED only: service may be inactive; reboot acceptance has not been established.'
fi
systemctl show bf3-lag-reconcile.service -p Result -p ExecMainStatus -p ActiveState
journalctl -b -u bf3-lag-reconcile.service -n 40 --no-pager
