#!/usr/bin/env python3
"""Fail-closed translation: Host bond0 VLANs -> PF0, retain IP/DNS/routes."""
import sys, yaml
from pathlib import Path
src, dst = map(Path, sys.argv[1:3])
y = yaml.safe_load(src.read_text())
if not isinstance(y, dict) or not isinstance(y.get('network'), dict):
    raise SystemExit('Not a Netplan network dict')
n = y['network']
if n.get('renderer', 'networkd') != 'networkd':
    raise SystemExit('Expected renderer: networkd')
bonds = n.get('bonds', {})
if 'bond0' not in bonds:
    raise SystemExit('Expected Host bond0 in this file; refusing to guess')
b = bonds['bond0']
slaves = set(b.get('interfaces', []))
if slaves != {'enp39s0f0np0', 'enp39s0f1np1'}:
    raise SystemExit('Unexpected Host bond members; inspect actual Netplan')
vlans = n.get('vlans', {})
for name, vid in [('bond0.1302', 1302), ('bond0.3048', 3048)]:
    if vlans.get(name, {}).get('id') != vid or vlans[name].get('link') != 'bond0':
        raise SystemExit(f'Expected VLAN interface {name} with id={vid} on bond0')
if sum(item.get('link') == 'bond0' for item in vlans.values()) != 2:
    raise SystemExit('Expected exactly two VLAN interfaces on bond0')
found = set()
for name, item in vlans.items():
    if item.get('link') == 'bond0':
        vid = int(item.get('id', -1))
        if vid not in (1302, 3048):
            raise SystemExit(f'Unexpected bond VLAN {name}: id={vid}')
        found.add(vid)
        item['link'] = 'enp39s0f0np0'  # preserve VLAN interface name
if found != {1302, 3048}:
    raise SystemExit(f'Expected exactly VLAN 1302 & 3048 on bond0, found {found}')
if any(x in b for x in ('addresses', 'routes', 'gateway4', 'gateway6', 'nameservers')) or b.get('dhcp4') or b.get('dhcp6'):
    raise SystemExit('Host bond0 contains L3 config; manual adaptation required')
for section in ('bridges', 'tunnels'):
    for name, item in n.get(section, {}).items():
        if 'bond0' in item.get('interfaces', []) or item.get('link') == 'bond0':
            raise SystemExit(f'Unexpected {section} reference to Host bond0: {name}')
eths = n.setdefault('ethernets', {})
if 'enp39s0f0np0' not in eths:
    raise SystemExit('PF0 must be explicitly declared in Netplan under expected name')
# When formerly inherited from bond, ensure physical PF0 MTU is not below VLAN MTUs.
old_mtu = b.get('mtu')
mtus = [int(item['mtu']) for item in vlans.values() if item.get('link') == 'enp39s0f0np0' and 'mtu' in item]
requested = max(([int(old_mtu)] if old_mtu is not None else [1500]) + mtus)
eths['enp39s0f0np0']['mtu'] = max(int(eths['enp39s0f0np0'].get('mtu', 1500)), requested)
del bonds['bond0']
if not bonds: n.pop('bonds')
dst.parent.mkdir(parents=True, exist_ok=True)
dst.write_text('# Generated for BF3 LAG cutover; original fully backed up.\n'+yaml.safe_dump(y, sort_keys=False))
print('Target Netplan:', dst)
print('Moved VLAN IDs:', sorted(found), '| PF0 MTU:', eths['enp39s0f0np0']['mtu'])
