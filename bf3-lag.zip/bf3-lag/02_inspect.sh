#!/usr/bin/env bash
# Read-only inventory: no link/address changes, service starts, or installation.
set -uo pipefail
SELF=$(cd -- "$(dirname -- "$0")" && pwd)
show() { printf '\n>>> '; printf '%q ' "$@"; printf '\n'; "$@" 2>&1 || printf '[INFO] unavailable / not yet configured\n'; }
show hostname
show uname -a
show cat /proc/sys/kernel/random/boot_id
show ip -br addr
show ip -4 route
show cat /proc/net/bonding/bond0
if [[ ${1:-host} == dpu ]]; then
  show grep -E '^LAG_HASH_MODE=' /etc/mellanox/mlnx-bf.conf
  show ovs-vsctl show
  for dev in p0 p1 pf0hpf pf1hpf; do show ip -d link show "$dev"; done
  show systemctl is-enabled bf3-lag-reconcile.service
  show systemctl show bf3-lag-reconcile.service -p ActiveState -p Result -p ExecMainStatus
  show ls -l /etc/netplan/70-bf3-lag.yaml
  exit 0
fi
show mstconfig -d 27:00.0 -e query
show cat /etc/netplan/01-cloud-net.yaml
show systemctl is-active rshim
show ls -l /dev/rshim0/misc
show ip -4 route get 192.168.100.2
if ip -4 route get 192.168.100.2 2>/dev/null | grep -q 'dev tmfifo_net0'; then
  # Quote the local script as one remote bash argument; retain a TTY for sudo.
  printf -v inventory '%q' "$(cat "$SELF/02_inspect.sh")"
  ssh -tt -o ConnectTimeout=8 ubuntu@192.168.100.2 "sudo bash -c $inventory -- dpu" ||
    echo '[INFO] DPU inspection unavailable; inspect from local ARM console.'
else
  echo '[INFO] TMFIFO route unavailable. Inspect DPU again after the stage step.'
fi
echo 'Inventory only; this output is not a readiness/acceptance result.'
