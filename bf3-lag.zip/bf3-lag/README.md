# HGX H200 — BlueField-3 LAG Script Package

Host-driven scripts for migrating LACP to BlueField-3 and making the DPU LAG and Host management path persistent across reboots.

Run from `/root/bf3-lag` on the HGX Host through KVM. ARM commands are sent over RShim/TMFIFO to `ubuntu@192.168.100.2`.

## Documentation

| Guide | Contents |
| --- | --- |
| [Operating procedure](docs/operations.md) | Required configuration, package verification, preparation, cutover, persistence, reboot validation, and limitations |
| [Recovery and rollback](docs/rollback/README.md) | Select a recovery path and capture diagnostic state |
| [Preparation recovery](docs/rollback/preparation.md) | Case A: preparation or staging failures |
| [Runtime and management recovery](docs/rollback/runtime.md) | Cases B–C: failed cutover and unavailable TMFIFO |
| [Persistence recovery](docs/rollback/persistence.md) | Cases D–E: incomplete installation and post-reboot failures |
| [Policy rollback](docs/rollback/policies.md) | Cases F–H: anti-spoofing, TX limits, and RX meters |
| [Return to NIC Mode](docs/rollback/nic-mode.md) | Case I: restore the Host-managed architecture |

## Package Scope

The package contains LAG deployment, validation, persistence, and runtime rollback scripts. Anti-spoofing and rate-limit recovery examples refer to separate deployment-report artifacts; those scripts and benchmark results are not included here.

Read the operating guide and select the relevant rollback path before disruptive changes. `rollback-runtime` restores the pre-cutover DPU-mode topology; it does not change firmware to NIC Mode.

Validate package contents with `sha256sum -c SHA256SUMS` from `/root/bf3-lag`. Keep existing backup/state directories intact.
