#!/usr/bin/env bash
# Run as root on HGX KVM. Restore pre-cutover /etc/netplan (all files).
set -Eeuo pipefail
BASE=/root/bf3-lag/state
[[ $(id -u) -eq 0 ]] || exit 1
[[ -d "$BASE/orig-netplan" ]] || { echo 'No saved original Netplan'; exit 1; }
echo '[HOST ROLLBACK] Restore original Netplan'
# Restore original /etc/netplan wholesale, including files removed during maintenance.
cp -a "$BASE/orig-netplan/." /etc/netplan/
# Remove only our target VLAN interface names (original links may still be active).
# Do NOT delete other netplan YAML written by unrelated services here.
netplan generate
for d in bond0.1302 bond0.3048; do ip link show "$d" >/dev/null 2>&1 && ip link delete "$d" || true; done
# Netplan may not automatically remove obsolete virtual devices.
netplan apply
ip -4 route
ip -br addr
[[ -f /proc/net/bonding/bond0 ]] || echo 'WARNING: bond0 not present, inspect systemd-networkd and run netplan apply.'
echo '[HOST ROLLBACK] Restored original Host Netplan. Ensure DPU original OVS path is restored too.'
