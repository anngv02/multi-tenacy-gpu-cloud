#!/usr/bin/env bash
# DPU ARM, read-only, with 'preflight' option.
set -euo pipefail
MODE=${1:-verify}
echo '==== ARM identity / LAG HASH ===='
uname -a
grep -E '^LAG_HASH_MODE=' /etc/mellanox/mlnx-bf.conf || true
echo '==== DPU OVS ===='
ovs-vsctl show
echo '==== PORTS ===='
for d in p0 p1 pf0hpf pf1hpf; do ip -br link show "$d"; done
echo '==== DPU BOND ===='
if [[ -f /proc/net/bonding/bond0 ]]; then
 cat /proc/net/bonding/bond0
else
 echo 'DPU bond0 is not yet present'
fi
if [[ "$MODE" == preflight ]]; then
  [[ $(ovs-vsctl port-to-br p0) == ovsbr1 ]] || exit 1
  [[ $(ovs-vsctl port-to-br p1) == ovsbr2 ]] || exit 1
  [[ $(ovs-vsctl port-to-br pf0hpf) == ovsbr1 ]] || exit 1
  [[ $(ovs-vsctl port-to-br pf1hpf) == ovsbr2 ]] || exit 1
  grep -Eq '^LAG_HASH_MODE=["\x27]?yes["\x27]?' /etc/mellanox/mlnx-bf.conf || exit 1
  echo 'DPU preflight passed (topology only).'
else
  [[ -f /proc/net/bonding/bond0 ]] || exit 1
  # Observe slow-period LACPDUs (~30 s); allow up to 120 s for switch negotiation.
  ready=0
  for _ in {1..40}; do
    ports=$(awk '/Active Aggregator Info:/ {f=1; next} f && /Number of ports:/ {print $4; exit}' /proc/net/bonding/bond0)
    peer=$(awk '/Active Aggregator Info:/ {f=1; next} f && /Partner Mac Address:/ {print $4; exit}' /proc/net/bonding/bond0)
    if [[ "$ports" == 2 && -n "$peer" && "$peer" != 00:00:00:00:00:00 ]]; then ready=1; break; fi
    printf "[LACP wait] active_ports=%s partner=%s; checking again...\n" "${ports:-unknown}" "${peer:-unknown}"
    sleep 3
  done
  cat /proc/net/bonding/bond0 | grep -E 'Aggregator ID|Number of ports|Partner Mac Address|Slave Interface|MII Status|Speed|port state:|Actor Churn State|Partner Churn State'
  [[ $ready == 1 ]] || { echo 'LACP NOT ACCEPTED: active aggregator must contain 2 ports and valid partner MAC. Run rollback.'; exit 1; }
  echo 'Check: Active Aggregator Number of ports=2 and nonzero Partner MAC; both member states collecting/distributing.'
  echo 'Hardware forwarding:'
  ovs-appctl dpctl/dump-flows --names type=offloaded | head -30 || true
fi
