#!/usr/bin/env bash
# Run on HGX Host. Explicit phases; no automatic reboot.
set -Eeuo pipefail
SELF=$(cd -- "$(dirname -- "$0")" && pwd)
ACTION=${1:-help}
case "$ACTION" in
  help|-h|--help)
    cat <<'HELP'
Usage: bash bf3-lag.sh ACTION
  inspect              Read-only Host and DPU inventory (TMFIFO must already work)
  prepare              Back up Host Netplan; generate and validate target offline
  stage                Set Host TMFIFO address; copy runtime tools and preflight
  cutover              Disruptive cutover; requires ACK_TOR_LACP=YES and KVM
  verify-runtime       Check Host VLANs and DPU LACP/OVS/MTU
  install-persistence  Stage DPU + Host boot configuration; no apply/reboot
  verify-staged        Validate installed boot configuration and runtime
  verify-boot          Require BOTH Host and DPU rebooted since installation
  rollback-runtime     DPU then Host rollback; refuses DPU persistence config
  help                 Show help
Run phases individually. Read README.md and review the generated Netplan diff.
HELP
    exit 0 ;;
esac
[[ $(id -u) -eq 0 ]] || { echo 'Run on HGX Host KVM as root (sudo -i)'; exit 1; }
case "$ACTION" in
  inspect) exec bash "$SELF/02_inspect.sh" host ;;
  prepare) exec bash "$SELF/00_prepare_host.sh" ;;
  stage) exec bash "$SELF/01_stage_dpu.sh" ;;
  cutover) exec bash "$SELF/40_cutover_from_kvm.sh" ;;
  verify-runtime) exec bash "$SELF/50_verify_runtime_from_kvm.sh" ;;
  install-persistence)
    bash "$SELF/50_verify_runtime_from_kvm.sh"
    exec bash "$SELF/persistence/40_install_from_kvm.sh" ;;
  verify-staged) exec bash "$SELF/persistence/50_verify_from_kvm.sh" staged ;;
  verify-boot) exec bash "$SELF/persistence/50_verify_from_kvm.sh" boot ;;
  rollback-runtime) exec bash "$SELF/90_rollback_from_kvm.sh" ;;
  *) echo "Unknown action: $ACTION (run: bash bf3-lag.sh help)" >&2; exit 2 ;;
esac
