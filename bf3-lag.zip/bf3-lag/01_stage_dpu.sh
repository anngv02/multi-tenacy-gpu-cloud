#!/usr/bin/env bash
# Run from HGX KVM console after 00_prepare_host.sh.
set -Eeuo pipefail
BASE=/root/bf3-lag
SELF="$(cd -- "$(dirname -- "$0")" && pwd)"
[[ $(id -u) -eq 0 ]] || exit 1
[[ -f "$BASE/state/host-prepared" ]] || { echo 'Run 00_prepare_host.sh first'; exit 1; }
if ! ip link show tmfifo_net0 >/dev/null 2>&1; then
  echo 'tmfifo_net0 missing. Fix RShim before cutover.'; exit 1
fi
ip link set tmfifo_net0 up
ip -4 addr show dev tmfifo_net0 | grep -q '192.168.100.1/30' || ip addr add 192.168.100.1/30 dev tmfifo_net0
ip -4 route get 192.168.100.2
ping -I tmfifo_net0 -c 1 -W 3 192.168.100.2 >/dev/null || { echo 'TMFIFO ping failed'; exit 1; }
DPU=ubuntu@192.168.100.2
ssh -o ConnectTimeout=8 "$DPU" 'mkdir -p ~/bf3-lag'
scp -o ConnectTimeout=8 "$SELF/10_apply_dpu_lag.sh" "$SELF/11_rollback_dpu.sh" "$SELF/31_verify_dpu.sh" "$DPU:~/bf3-lag/"
ssh -tt "$DPU" 'sudo bash ~/bf3-lag/31_verify_dpu.sh preflight'
echo 'DPU scripts copied. DO NOT execute them until KVM and Host rollback are ready.'
