#!/usr/bin/env bash
# Run as root in HGX KVM console BEFORE the cutover. No datapath changes.
set -Eeuo pipefail
BASE=/root/bf3-lag
CFG=/etc/netplan/01-cloud-net.yaml
SELF="$(cd -- "$(dirname -- "$0")" && pwd)"
[[ $(id -u) -eq 0 ]] || { echo 'Run as root'; exit 1; }
[[ -f "$CFG" ]] || { echo "Missing $CFG"; exit 1; }
for c in python3 netplan ip ssh scp mstconfig; do command -v "$c" >/dev/null || { echo "Missing $c"; exit 1; }; done
python3 -c 'import yaml' || { echo 'Missing python3-yaml. Install before maintenance.'; exit 1; }
for dev in enp39s0f0np0 enp39s0f1np1 tmfifo_net0; do ip link show "$dev" >/dev/null || { echo "Missing $dev"; exit 1; }; done
ip -4 addr show | grep -Fq '171.232.252.202/' || { echo 'Public IP not found'; exit 1; }
ip -4 addr show | grep -Fq '10.29.252.239/' || { echo 'Private IP not found'; exit 1; }
[[ -f /proc/net/bonding/bond0 ]] || { echo 'Original host bond0 is missing'; exit 1; }
if [[ -d "$BASE/state/orig-netplan" ]]; then echo "Backup already exists in $BASE; review prior attempt; will not overwrite backup"; exit 1; fi
mkdir -p "$BASE/state/orig-netplan" "$BASE/state/target-root/etc/netplan"
cp -a /etc/netplan/. "$BASE/state/orig-netplan/"
# Preserve overlays for staging validation; only /etc/netplan modifications are written on host.
cp -a /etc/netplan/. "$BASE/state/target-root/etc/netplan/"
python3 "$SELF/host_prepare_netplan.py" "$CFG" "$BASE/state/target-root/etc/netplan/01-cloud-net.yaml"
chmod 600 "$BASE/state/target-root/etc/netplan/01-cloud-net.yaml"
netplan generate --root-dir "$BASE/state/target-root"
cp -a "$BASE/state/target-root/etc/netplan/01-cloud-net.yaml" "$BASE/state/host-target.yaml"
mstconfig -d 27:00.0 -e query > "$BASE/state/mstconfig.before.txt"
if ! grep -q 'LAG_RESOURCE_ALLOCATION.*PRE_ALLOCATION(1).*PRE_ALLOCATION(1)' "$BASE/state/mstconfig.before.txt"; then
  echo 'ERROR: LAG_RESOURCE_ALLOCATION Current/Next is not PRE_ALLOCATION(1)'; exit 1
fi
cat /proc/net/bonding/bond0 > "$BASE/state/host-bond.before.txt"
ip -d -br link > "$BASE/state/host-link.before.txt"
ip -4 route > "$BASE/state/host-route.before.txt"
touch "$BASE/state/host-prepared"
echo 'READY: original Netplan backed up, target generated/validated. No network change.'
echo 'Review: diff -u /etc/netplan/01-cloud-net.yaml /root/bf3-lag/state/host-target.yaml'
