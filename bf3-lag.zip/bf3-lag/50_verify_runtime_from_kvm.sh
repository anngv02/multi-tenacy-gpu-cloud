#!/usr/bin/env bash
# Read-only config checks; probes produce normal ICMP/TCP traffic.
set -Eeuo pipefail
SELF=$(cd -- "$(dirname -- "$0")" && pwd)
[[ $(id -u) -eq 0 ]] || exit 1
for spec in 'bond0.1302 171.232.252.202/24' 'bond0.3048 10.29.252.239/25'; do
  read -r dev addr <<< "$spec"
  [[ -e "/sys/class/net/$dev/lower_enp39s0f0np0" ]] || { echo "$dev not on PF0"; exit 1; }
  ip -4 -o addr show dev "$dev" | awk '{print $4}' | grep -Fx "$addr"
done
[[ ! -e /sys/class/net/bond0 ]] || { echo 'Host bond0 still exists'; exit 1; }
ip -4 route get 192.168.100.2 | grep 'dev tmfifo_net0'
ip -4 route get 171.232.252.212 from 171.232.252.202
printf -v preflight '%q' "$(cat "$SELF/persistence/10_dpu_preflight.sh")"
ssh -tt -o ConnectTimeout=8 ubuntu@192.168.100.2 "sudo bash -c $preflight"
if ! ping -I 171.232.252.202 -c 2 -W 3 171.232.252.212; then
  python3 - <<'PY'
import socket
with socket.socket() as s:
    s.settimeout(5)
    s.bind(('171.232.252.202', 0))
    s.connect(('171.232.252.212', 5201))
print('Public peer TCP/5201 reachable')
PY
fi
if [[ -n ${PRIVATE_PEER:-} ]]; then
  ping -I 10.29.252.239 -c 3 -W 3 "$PRIVATE_PEER"
else
  echo 'PRIVATE L3 NOT TESTED: rerun with PRIVATE_PEER=<known private peer> for acceptance.'
fi
echo 'PASS: runtime topology/LACP/MTU/public reachability. Review private L3 and actual offload traffic separately.'
