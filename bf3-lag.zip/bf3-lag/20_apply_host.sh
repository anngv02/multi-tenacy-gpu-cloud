#!/usr/bin/env bash
# Run as root FROM HGX KVM console AFTER DPU LAG runtime is created.
set -Eeuo pipefail
BASE=/root/bf3-lag/state
CFG=/etc/netplan/01-cloud-net.yaml
[[ $(id -u) -eq 0 ]] || exit 1
[[ -f "$BASE/host-prepared" && -s "$BASE/host-target.yaml" ]] || { echo 'Run prepare script first'; exit 1; }
[[ -e /proc/net/bonding/bond0 ]] || { echo 'Original host bond0 not present; unexpected state'; exit 1; }
cmp -s "$CFG" "$BASE/orig-netplan/01-cloud-net.yaml" || { echo 'Host Netplan changed since backup; abort'; exit 1; }
# Critical: We cannot see DPU changes over public IP. TMFIFO must be reachable.
ping -I tmfifo_net0 -c 1 -W 2 192.168.100.2 >/dev/null || { echo 'TMFIFO unavailable: abort'; exit 1; }
echo '[HOST] Installing tested target Netplan. VLAN interface names are retained.'
install -m 600 "$BASE/host-target.yaml" "$CFG"
if ! netplan generate; then
  echo '[HOST] Invalid generated Netplan; restore original immediately'
  install -m 600 "$BASE/orig-netplan/01-cloud-net.yaml" "$CFG"
  netplan generate || true
  exit 1
fi
echo '[HOST] Removing old VLAN interfaces and old Host bond0 (KVM required)'
for d in bond0.1302 bond0.3048; do ip link show "$d" >/dev/null 2>&1 && ip link delete "$d" || true; done
ip link show bond0 >/dev/null 2>&1 && ip link delete bond0 || true
if ! netplan apply; then
  echo '[HOST] netplan apply failed. Run 21_rollback_host.sh and DPU rollback'; exit 1
fi
sleep 3
echo '[HOST] Current IPs / routes'
ip -br addr
ip -4 route
for address in 171.232.252.202 10.29.252.239; do
  ip -4 addr show | grep -q "$address/" || { echo "Missing IP $address; use rollback"; exit 1; }
done
# Verify the original bond has been retired from datapath and both tagged VLANs
# use the physical Host PF0 as their lower device (their names remain bond0.*).
for vlan in bond0.1302 bond0.3048; do
  [[ -e "/sys/class/net/$vlan" ]] || { echo "VLAN $vlan missing"; exit 1; }
  [[ -e "/sys/class/net/$vlan/lower_enp39s0f0np0" ]] || {
    echo "VLAN $vlan is not attached to PF0; current lower devices:";
    ls -l "/sys/class/net/$vlan"/lower_* 2>/dev/null || true;
    exit 1;
  }
done
ip -4 route get 171.232.252.212 from 171.232.252.202
# ICMP may be filtered; known test server has iperf3 control TCP/5201.
# Allow some time for VLAN/ARP/forwarding to converge, then verify a real L3 connection.
end=$((SECONDS + 90))
connected=0
while (( SECONDS < end )); do
  if ping -I 171.232.252.202 -c 1 -W 2 171.232.252.212 >/dev/null 2>&1; then
    connected=1; echo '[HOST] Public peer responds to ICMP'; break
  fi
  if python3 - <<'PYCONN'
import socket
s=socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.settimeout(3)
s.bind(('171.232.252.202',0))
try:
    s.connect(('171.232.252.212',5201))
finally:
    s.close()
PYCONN
  then
    connected=1; echo '[HOST] Public peer TCP 5201 reachable'; break
  fi
  echo '[HOST] Public peer not yet reachable; retry in 3 s ...'
  sleep 3
done
[[ $connected == 1 ]] || { echo 'External connectivity FAILED after 90s; rollback required'; exit 1; }
echo 'HOST CUTOVER FINISHED. DPU LACP was verified before Host changed.'
