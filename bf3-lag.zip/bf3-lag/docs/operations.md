# HGX H200 — LAG Operations Guide

[Overview](../README.md) | [Recovery and rollback](rollback/README.md)

Start after logging into the **HGX H200 (HGX202) Host OS through the KVM console**, with the script package located at `/root/bf3-lag`. All commands in this guide run on the Host; commands for BlueField ARM are invoked through `ssh ubuntu@192.168.100.2` over RShim/TMFIFO.

Start a root session and enter the working directory:

```bash
sudo -i
cd /root/bf3-lag
```

Keep this KVM session open throughout configuration and recovery.

## 1. Scope and Required Configuration

| Component | Value Used by This Package |
| --- | --- |
| Host | Ubuntu 24.04.4; Netplan/networkd; PCI `27:00.0` |
| BlueField ARM | Ubuntu 22.04.3; OVS; SSH account `ubuntu` |
| Host PF0 / PF1 | `enp39s0f0np0` / `enp39s0f1np1` |
| DPU uplink / representor | `p0`, `p1` / `pf0hpf`, `pf1hpf` |
| Public VLAN | `bond0.1302`, ID 1302, `171.232.252.202/24`, gateway `171.232.252.254` |
| Private VLAN | `bond0.3048`, ID 3048, `10.29.252.239/25` |
| Public test peer | `171.232.252.212`: ICMP or TCP/5201 |
| TMFIFO management | Host `192.168.100.1/30` → ARM `192.168.100.2` |
| Firmware/configuration prerequisites | Current and Next `LAG_RESOURCE_ALLOCATION=PRE_ALLOCATION(1)`; ARM `LAG_HASH_MODE="yes"` |
| MTU | Taken from the Host bond at cutover; persistence uses the active DPU MTU, within 1500–9000 |

Do not use this package unchanged for other nodes, IP addresses, or interfaces. The scripts do not modify firmware or configure the ToR. If firmware prerequisites are not met, follow the separate firmware procedure and check again.

Before cutover, confirm on the ToR that p0+p1 share the same LACP System/Key (or compatible MLAG), allow tagged VLANs 1302/3048, and use a suitable MTU. Link UP alone does not prove that LACP is correct. KVM access must be independent of the two uplinks being modified.

**Before:** Host bond0 aggregates both PFs and carries both VLANs; ARM has `ovsbr1:p0+pf0hpf` and `ovsbr2:p1+pf1hpf`.

**After:** ARM Linux bond0 aggregates p0+p1 and joins ovsbr1 alongside pf0hpf; pf1hpf is removed from OVS. Both Host VLANs move to PF0 as their parent, retaining the names `bond0.1302`/`bond0.3048`, IP addresses, routes, and DNS. The Host no longer has Linux bond0. SFs remain unchanged.

## 2. Layout and Paths

```text
bf3-lag/
  README.md                          overview and documentation index
  docs/operations.md                 operating procedure
  docs/rollback/                     recovery scenarios
  bf3-lag.sh                         Host orchestration command
  02_inspect.sh                      inspect state without configuration changes
  00_prepare_host.sh, 01_stage_dpu.sh preparation/backup/staging
  10_apply_dpu_lag.sh, 20_apply_host.sh
  31_verify_dpu.sh, 40_cutover_from_kvm.sh
  50_verify_runtime_from_kvm.sh
  11_rollback_dpu.sh, 21_rollback_host.sh, 90_rollback_from_kvm.sh
  host_prepare_netplan.py
  persistence/                       install, verify, and remove boot configuration
  VERSION.txt, SHA256SUMS
```

Standard code paths: `/root/bf3-lag` on the Host, `/home/ubuntu/bf3-lag` on ARM, and the `persistence/` subdirectory within each. Backup/state directories used for recovery:

| Backup/State | Location |
| --- | --- |
| Host Netplan before cutover | `/root/bf3-lag/state/orig-netplan/` |
| Generated Host target | `/root/bf3-lag/state/host-target.yaml` |
| DPU runtime snapshot and original MTU | `/var/lib/bf3-lag/` on ARM |
| DPU persistence backup | `/var/lib/bf3-lag-persistence/backup/` on ARM |
| Host management backup | `/root/bf3-lag-persistence-backup/` |

Do not delete backups/state to force scripts to run again.

## 3. Check the Script Package on the Host

From a root session in `/root/bf3-lag`:

```bash
sha256sum -c SHA256SUMS
find . -type f -name '*.sh' -print0 | xargs -0 -n1 bash -n
bash -n persistence/bf3-lag-reconcile
bash bf3-lag.sh help
```

The Host requires `python3`, `python3-yaml`, `netplan`, `ip`, `ping`, `ssh`, `scp`, `mstconfig`, and RShim. ARM requires `python3-yaml`, Netplan, systemd-networkd, NetworkManager, OVS, iproute2, and bonding. Install dependencies before maintenance. The scripts use Bash, and the `ubuntu` SSH login shell must support Bash syntax. The scripts use `scp` to copy files from the Host to ARM over TMFIFO.

## 4. Inspect the Current State and Choose a Starting Point

```bash
bash bf3-lag.sh inspect
```

This command inspects Host IP addresses, routes, bond, firmware, and RShim, plus ARM OVS/LAG if the TMFIFO route exists; it does not assign IP addresses, enable services, or copy files. An “unavailable” message at this stage indicates an issue to address, not a PASS. If TMFIFO is not yet available, inspect ARM again after `stage`.

| Current State | Next Step |
| --- | --- |
| Host still has bond0; DPU still has the two baseline bridges | Follow sections 5 → 6 → 7 |
| Runtime is already correct: Host VLANs on PF0, ARM bond0 operational | Run `verify-runtime`; if it passes, proceed to section 7. Do not rerun prepare/cutover |
| Persistence was installed using an older package | Preserve backups; manually check the version/configuration. This package does not automatically overwrite or migrate old state |
| Topology differs from baseline, custom OpenFlow/meters are present, or firmware is incorrect | Stop configuration and adapt the procedure to the actual state |

If runtime was configured with an older package, retain the original Host Netplan backup and DPU MTU to support rollback. Do not create a “before cutover” backup from a post-cutover state.

## 5. Back Up and Prepare — No Datapath Changes Yet

```bash
bash bf3-lag.sh prepare
diff -u /etc/netplan/01-cloud-net.yaml /root/bf3-lag/state/host-target.yaml
cat /root/bf3-lag/state/mstconfig.before.txt
```

It is normal for `diff` to return 1 when changes exist. Confirm that only the Host bond is removed, both VLAN parents move to PF0, and the PF0 MTU is set correctly; IP addresses, routes, and DNS must remain unchanged. The script validates Netplan in a temporary directory without running `netplan apply`.

Start RShim if it is not already running, then stage:

```bash
systemctl start rshim
ls -l /dev/rshim0/misc
bash bf3-lag.sh stage
bash bf3-lag.sh inspect
ls -l 90_rollback_from_kvm.sh 21_rollback_host.sh
ssh ubuntu@192.168.100.2 'ls -l ~/bf3-lag/11_rollback_dpu.sh'
```

`stage` brings up tmfifo_net0, adds the management IP if missing, copies three runtime scripts to ARM, and runs preflight checks. This changes management configuration but does not yet alter the uplink/VLAN datapath. SSH/sudo passwords may be requested at the KVM console.

## 6. Runtime Cutover — Network Interruption Expected

After verifying ToR/MLAG/VLAN configuration, KVM access, and rollback readiness:

```bash
ACK_TOR_LACP=YES bash bf3-lag.sh cutover
bash bf3-lag.sh verify-runtime
# If a real private peer allows ICMP, replace the following value:
PRIVATE_PEER='IP-peer-private' bash bf3-lag.sh verify-runtime
```

The controller configures the ARM bond first, waits up to approximately 120 seconds for LACP to have two ports and a valid partner MAC, then applies Host Netplan and checks the public peer for up to approximately 90 seconds. On failure, it attempts DPU rollback followed by Host rollback; passwords may be required. Keep the KVM console attended.

`verify-runtime` checks the IP/mask on the correct VLAN, PF0 as parent, the absence of Host bond0, DPU mode/hash/LACP rate, OVS, MTU, and actor/partner collecting/distributing states. If PRIVATE_PEER is not provided, the result explicitly states that private L3 connectivity was not tested. When the public peer does not allow ICMP, TCP/5201 is used as a fallback; that service must be running on the peer.

Proceed to persistence only after runtime validation passes. Do not reboot between cutover and completion of persistence installation.

## 7. Install Persistence — No Network Apply or Reboot

```bash
bash bf3-lag.sh install-persistence
bash bf3-lag.sh verify-staged
```

The controller first checks runtime and validates the Host management Netplan configuration offline; copies the subpackage to `~/bf3-lag/persistence` on ARM; then installs ARM followed by the Host. The following configuration is created:

| Location | File/Change |
| --- | --- |
| ARM | `/etc/netplan/70-bf3-lag.yaml`: networkd manages p0/p1/bond0; MTU is taken from runtime |
| ARM | `/etc/NetworkManager/conf.d/98-bf3-lag-unmanaged.conf`: NM does not manage those three interfaces |
| ARM | `/usr/local/sbin/bf3-lag-reconcile`, unit `/etc/systemd/system/bf3-lag-reconcile.service`, enabled at boot |
| Host | `/etc/netplan/90-bf3-tmfifo-host.yaml`, RShim enabled |

The installer does not modify cloud-init/60-mlnx, change OVSDB, or run a live `netplan apply`; NetworkManager continues to manage OOB/TMFIFO as before. Do not copy the package's MTU 9000 template directly: the installer replaces it with the validated runtime MTU.

Reconcile waits for interfaces/OVS to become ready and checks the bond created by networkd; it provides a fallback if the bond has not appeared, restores the pf0hpf MTU, and restores the OVS bond reference if missing. It does not remove or recreate a correctly configured bond. Its operation must be validated against the device's specific BSP/driver.

`verify-staged` checks installed files, MTU/LACP, RShim, and service enablement. The DPU service has not run yet, so an inactive state is normal at this stage. Persistence across reboots has not yet been validated.

## 8. Reboot and Validate

Perform this during maintenance, keeping KVM/RShim console access available. **The Host and ARM have separate boot lifecycles**; both must be checked. The scripts do not reboot automatically.

To test a separate ARM reboot, run from the Host KVM console after `verify-staged` passes and workloads have been stopped:

```bash
ssh -tt ubuntu@192.168.100.2 'sudo reboot'
# SSH disconnection during ARM reboot is expected. Wait for ARM to return, then recheck RShim/SSH.
bash bf3-lag.sh verify-staged
```

Then reboot the Host from KVM:

```bash
reboot
```

Once the Host is back up:

```bash
sudo -i
cd /root/bf3-lag
systemctl is-active rshim
ls -l /dev/rshim0/misc
ip -4 route get 192.168.100.2
bash bf3-lag.sh verify-boot
# Add PRIVATE_PEER as in section 6 if a suitable peer is available.
```

`verify-boot` requires both Host and ARM boot IDs to differ from those recorded during installation; the DPU service must be active (exited), with Result=success and exit code 0, and must have run during the current boot. Validation fails if only the Host rebooted and ARM did not. Boot IDs prove only that a reboot occurred after installation, not a cold power cycle or success on every future boot.

From the Host, also inspect ARM while real traffic is flowing:

```bash
ssh -tt ubuntu@192.168.100.2 'sudo journalctl -b -u bf3-lag-reconcile.service --no-pager'
ssh ubuntu@192.168.100.2 'cat /proc/net/bonding/bond0'
ssh -tt ubuntu@192.168.100.2 'sudo ovs-vsctl show'
ssh -tt ubuntu@192.168.100.2 'sudo ovs-appctl dpctl/dump-flows --names type=offloaded'
```

Confirm that both links actually operate at 200GbE, both members forward traffic, private/public VLANs are reachable, and corresponding offloaded flows exist. Two LACP members do not imply 400 Gb/s of application throughput.

## Limitations and References

The scripts have been checked for syntax and Netplan conversion using sample data; they have not been validated on actual HGX/DPU hardware. Consider deployment successful only after completing the runtime, persistence, and reboot checks above.

NVIDIA requires LAG to be handled again after the driver is ready following reboot/reload. The networkd + reconcile model must be validated against the machine's BSP/driver; this is not a certification of support for all firmware versions. The package does not automatically handle `openibd restart`, cold power cycles, OVSDB loss, MLAG failures, anti-spoofing, or rate limits.

- [NVIDIA DOCA 2.9.3 — Link Aggregation](https://networking-docs.nvidia.com/doca/archive/2-9-3/link-aggregation)
- [systemd.service — oneshot/RemainAfterExit](https://www.freedesktop.org/software/systemd/man/257/systemd.service.html)
