#!/usr/bin/env bash
# Safe re-create original two OVS uplinks. Run on DPU ARM via TMFIFO.
set -Eeuo pipefail
[[ $(id -u) -eq 0 ]] || { echo 'sudo required'; exit 1; }
if [[ -e /etc/netplan/70-bf3-lag.yaml || -e /etc/systemd/system/bf3-lag-reconcile.service ]] ||
   compgen -G '/run/systemd/network/*netplan*bond0*' >/dev/null; then
  echo 'STOP: DPU persistence/generated networkd config still present. See README recovery section.'; exit 1
fi
echo '[DPU ROLLBACK] Restoring ovsbr1:p0+pf0hpf and ovsbr2:p1+pf1hpf'
if ip link show bond0 >/dev/null 2>&1; then
  ovs-vsctl --if-exists del-port ovsbr1 bond0
  ip link set bond0 down || true
  ip link set p0 nomaster || true
  ip link set p1 nomaster || true
  ip link delete bond0 || true
fi
ovs-vsctl --may-exist add-br ovsbr1
ovs-vsctl --may-exist add-br ovsbr2
ovs-vsctl --may-exist add-port ovsbr1 p0
ovs-vsctl --may-exist add-port ovsbr1 pf0hpf
ovs-vsctl --may-exist add-port ovsbr2 p1
ovs-vsctl --may-exist add-port ovsbr2 pf1hpf
# Restore SF ports only if interfaces exist; these were not removed by apply.
for pair in 'ovsbr1 en3f0pf0sf0' 'ovsbr2 en3f1pf1sf0'; do
  set -- $pair
  ip link show "$2" >/dev/null 2>&1 && ovs-vsctl --may-exist add-port "$1" "$2"
done
ip link set p0 up
ip link set p1 up
ip link set pf0hpf up || true
ip link set pf1hpf up || true
for d in p0 p1 pf0hpf pf1hpf; do
  f="/var/lib/bf3-lag/mtu-$d"
  if [[ -s "$f" ]]; then ip link set dev "$d" mtu "$(cat "$f")" || true; fi
done
# Assume verified baseline only; do not overwrite real OVS security rules.
for br in ovsbr1 ovsbr2; do
  flows=$(ovs-ofctl -O OpenFlow13 dump-flows "$br" | grep -E 'actions=' || true)
  [[ -n "$flows" ]] || ovs-ofctl -O OpenFlow13 add-flow "$br" 'priority=0,actions=NORMAL'
done
rm -f /var/lib/bf3-lag/applied
echo '[DPU ROLLBACK] Restored runtime OVS connections. Restore host netplan if cut over.'
ovs-vsctl show
